package flightscheduler_kkt5170;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Calendar;


public class WaitlistQueries {
    private static final String DATABASE_URL= "jdbc:derby://localhost:1527/FlightSchedulerDB-KaShingTsuikkt5170";
    private static final String USERNAME="java";
    private static final String PASSWORD="java";
    private ArrayList <Waitlist> waitlistNameList=new ArrayList<Waitlist>();
    private String customerName;
    private static String DELETE2 = "DELETE FROM WAITLIST WHERE FLIGHT = ?";
            
    private Connection connection;
    private PreparedStatement insertWaitlist;
    private PreparedStatement getBookingCustomers;
    ResultSet resultset;

    public WaitlistQueries(){
        try{
            connection= DriverManager.getConnection(DATABASE_URL,USERNAME,PASSWORD);
            getBookingCustomers = connection.prepareStatement("SELECT * FROM WAITLIST where DATES=?");
            insertWaitlist = connection.prepareStatement("INSERT INTO WAITLIST"+"(FLIGHT,dates,name,timestamps)"+"VALUES(?,?,?,?)");       
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        
    }
    
   public void addCustomertoWaitlist(String flightID,Date dates,String customerName) 
   { 
       Calendar calendar = Calendar.getInstance();
       Timestamp currentTimestamp = new java.sql.Timestamp(calendar.getTime().getTime());
       try{
            insertWaitlist.setString(1,flightID);
            insertWaitlist.setDate(2,dates);
            insertWaitlist.setString(3,customerName);
            insertWaitlist.setTimestamp(4,currentTimestamp);
            insertWaitlist.executeUpdate();
           }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
            }
   }
   
   public ArrayList<Waitlist>getWaitlistCustomers(String FlightID,Date Dates)
   { 
      this.waitlistNameList.clear();
        try
        {
        getBookingCustomers.setString(1, FlightID); 
        getBookingCustomers.setDate(1,  Dates);
        resultset= getBookingCustomers.executeQuery();
        while (resultset.next()) 
         {waitlistNameList.add(new Waitlist(resultset.getString("FLIGHT"),resultset.getDate("DATES"),resultset.getString("name")));}
        }
        catch(SQLException sqlException)
        {sqlException.printStackTrace();}
       return waitlistNameList;
   }
   
   public String getCustomerName()
   {
       return customerName;
   }
       public static void deletewaitlist2(String flightno)
       {
           try{
               Connection connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
               PreparedStatement deleteWaitlist = connection.prepareStatement(DELETE2);
               deleteWaitlist.setString(1, flightno);
               deleteWaitlist.executeUpdate();
               }
           catch(SQLException sqlException)
           {
               sqlException.printStackTrace();
           }
       }
   
}
