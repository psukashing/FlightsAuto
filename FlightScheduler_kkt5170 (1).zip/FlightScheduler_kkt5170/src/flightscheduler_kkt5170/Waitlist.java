package flightscheduler_kkt5170;

import java.sql.Date;
public class Waitlist {
    private String flightID;
    private Date dates;
    private String customerName;

    public Waitlist(String flightID,Date dates, String customerName){
    setflightID(flightID);
    setdates(dates);
    setcustomerName(customerName);
    }

    
    
    public String getflightID(){ return flightID;}
    public String getcustomerName(){ return customerName;}
    public Date getdates(){ return dates;}
    public void setflightID(String flightID){this.flightID = flightID;}
    public void setdates(Date dates){this.dates = dates;}
    public void setcustomerName(String customerName){this.customerName = customerName;}
}
