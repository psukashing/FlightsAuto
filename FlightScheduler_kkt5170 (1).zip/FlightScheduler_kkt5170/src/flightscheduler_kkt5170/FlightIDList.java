package flightscheduler_kkt5170;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class FlightIDList {


    private static final String DATABASE_URL= "jdbc:derby://localhost:1527/FlightSchedulerDB-KaShingTsuikkt5170";
    private static final String USERNAME="java";
    private static final String PASSWORD="java";
    private PreparedStatement ComboFlight;
    private Connection connection;
    String flightList[]=new String[30];

    public FlightIDList() {
        try {
            Connection connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
            ComboFlight = connection.prepareStatement("SELECT NAME FROM Flight");
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }

    public String[] getflightlist() {
        
        try {
            ResultSet resultset = ComboFlight.executeQuery();
            for(int i = 0;resultset.next();i++)
            {
                flightList[i] = (String) resultset.getString(1);    
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return flightList;
    }
    
    public static void deleteflight(String flightID)
    {
        try
        {
            Connection connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
            PreparedStatement deleteflight = connection.prepareStatement("DELETE FROM FLIGHT WHERE NAME = ?");
            deleteflight.setString(1, flightID);
            deleteflight.executeUpdate();
            
             PreparedStatement deleteFlightBooking = connection.prepareStatement("DELETE FROM BOOKING WHERE FLIGHT = ?");
            deleteFlightBooking.setString(1, flightID);
            deleteFlightBooking.executeUpdate();
            
            PreparedStatement deleteFlightWaitlist = connection.prepareStatement("DELETE FROM WAITLIST WHERE FLIGHT = ?");
            deleteFlightWaitlist.setString(1, flightID);
            deleteFlightWaitlist.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }

}


