package flightscheduler_kkt5170;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException; 
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.sql.Date;

public class FlightDatesList {

    String format = "yyyy-MM-dd";
    private static final String DATABASE_URL= "jdbc:derby://localhost:1527/FlightSchedulerDB-KaShingTsuikkt5170";
    private static final String USERNAME="java";
    private static final String PASSWORD="java";
    private PreparedStatement ComboDates;
    String days[]=new String[30];

    public FlightDatesList() {

        try {
            Connection connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
            ComboDates = connection.prepareStatement("SELECT DAYS FROM DATES");
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

    }

    public String[] getdaylist() {
        try {
            ResultSet resultset = ComboDates.executeQuery();
            for(int i = 0;resultset.next();i++)
            {
                days[i] = convertDateToString( (Date) resultset.getDate(1),format);
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return days;
    }

    
    public String convertDateToString(Date date, String format) {
        String dateString = null;
        DateFormat dayformat = new SimpleDateFormat(format);
        try {
            dateString = dayformat.format(date);
        } catch (Exception exception) {
            System.out.println(exception);
        }
        return dateString;
    }
    
    public static void adddate(java.sql.Date day) {

        try {
            Connection connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
            PreparedStatement adddate = connection.prepareStatement("INSERT INTO DATES "
                            +"(DAYS) "
                            +"VALUES (?)");
            
            adddate.setDate(1,day);
            adddate.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

    }


}
