package flightscheduler_kkt5170;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.sql.Date;

public class BookingQueries {

    private static final String DATABASE_URL = "jdbc:derby://localhost:1527/FlightSchedulerDB-KaShingTsuikkt5170";
    private static final String USERNAME = "java";
    private static final String PASSWORD = "java";

    private Connection connection;
    private static ArrayList<String> bookingNameList = new ArrayList<String>();
    private static ArrayList<Booking> bookingList = new ArrayList<Booking>();
    private static ArrayList<String> daylist = new ArrayList<String>();
    private static ArrayList<String> namelist = new ArrayList<String>();
    private PreparedStatement insertBooking;
    private PreparedStatement getBookedSeats;
    private PreparedStatement getFlightSeats;
    private PreparedStatement getBookingCustomers;
    private int seatsBooked;
    private int flightseat;
    private PreparedStatement ComboCustomer;
    String CustomerList[]=new String[30];
    ResultSet resultset;
    private static boolean check = false;
    private static String DELETE = "DELETE FROM BOOKING WHERE DATES = ? AND NAME = ?";
    private static String FIND = "SELECT NAME FROM BOOKINGS WHERE DATE = ?";
    private static String FINDBOOKING = "SELECT FLIGHT, DATES FROM BOOKING WHERE NAME = ?";


    public BookingQueries() {
        try {
            connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
            getBookingCustomers = connection.prepareStatement("SELECT * FROM Booking where FLIGHT=? and DATES=?");
            ComboCustomer = connection.prepareStatement("SELECT NAME FROM BOOKING");
            getBookedSeats = connection.prepareStatement("select count(FLIGHT) from BOOKING where FLIGHT = ? and DATES = ?");
            getFlightSeats = connection.prepareStatement("select SEATS from FLIGHT where NAME = ?");
            insertBooking = connection.prepareStatement("INSERT INTO BOOKING" + "(Flight,dates,name)" + "VALUES(?,?,?)");

        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    
    }

    public void CustomerSubmit(String flightID, Date dates, String customerName) {

        int result = 0;

        try {
            insertBooking.setString(1, flightID);
            insertBooking.setDate(2, dates);
            insertBooking.setString(3, customerName);
            insertBooking.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }

    public ArrayList<Booking> getBookedCustomers(String FlightID, Date Dates) {
        this.bookingList.clear();
        try {
            getBookingCustomers.setString(1, FlightID);
            getBookingCustomers.setDate(2, Dates);
            resultset = getBookingCustomers.executeQuery();
            while (resultset.next()) {
                bookingList.add(new Booking(resultset.getString("FLIGHT"), resultset.getDate("DATES"), resultset.getString("name")));
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return bookingList;
    }
        public String[] getcustomerlist() {
        
        try {
            ResultSet resultset = ComboCustomer.executeQuery();
            for(int i = 0;resultset.next();i++)
            {
                CustomerList[i] = (String) resultset.getString(1);    
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return CustomerList;
    }
    public static ArrayList<String> getFlights() {
        ArrayList<String> flights = new ArrayList();
        
        try {
            Connection connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
            PreparedStatement request = connection.prepareStatement("SELECT * FROM FLIGHT");
            ResultSet flightResults = request.executeQuery();
            while (flightResults.next()) {
                flights.add(flightResults.getString("NAME"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return flights;
    }
    public static void addFlight(String flight, int seats) {
        if (!getFlights().contains(flight) && flight.length() > 0 && seats > 0) {

            try {
                Connection connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
                PreparedStatement request = connection.prepareStatement("INSERT INTO FLIGHT VALUES (?, ?)");
                request.setString(1, flight);
                request.setInt(2, seats);
                request.executeUpdate();
            } catch (SQLException sqlException) {
                sqlException.printStackTrace();
            }
        }
    }

    public int getBookedseat(String flightID, Date dates) {
        try {
            getBookedSeats.setString(1, flightID);
            getBookedSeats.setDate(2, dates);
            resultset = getBookedSeats.executeQuery();
            resultset.next();
            seatsBooked = resultset.getInt(1);
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return seatsBooked;
    }

    public int getFlightseat(String flightID) {
        try {
            getFlightSeats.setString(1, flightID);
            resultset = getFlightSeats.executeQuery();
            resultset.next();
            flightseat = resultset.getInt(1);
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return flightseat;
    }

    public boolean checkSeatAvailable(int Bookseat, int Flightseat) {

        return Bookseat >= Flightseat;
    }

    public static String deletebooking(String customer, String day) {
        String cs = "";
        try {
            Connection connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
            PreparedStatement findflight = connection.prepareStatement("select FLIGHT FROM BOOKING where NAME = ? and DATES =?");
            findflight.setString(1, customer);
            findflight.setString(2, day);
            ResultSet rs1 = findflight.executeQuery();
            rs1.next();
            cs = rs1.getString("FLIGHT");

            PreparedStatement deletebooking = connection.prepareStatement("DELETE FROM BOOKING WHERE DATES = ? AND NAME = ?");
            deletebooking = connection.prepareStatement("DELETE FROM BOOKING WHERE DATES = ? AND NAME = ?");
            deletebooking.setString(1, day);
            deletebooking.setString(2, customer);
            deletebooking.executeUpdate();

        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return cs;
    }

    public static ArrayList flightbycustomer(String name) {
        try {
            Connection connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
            PreparedStatement findbooking = connection.prepareStatement(FINDBOOKING);
            findbooking.setString(1, name);
            ResultSet rs2 = findbooking.executeQuery();
            bookingNameList.clear();
            while (rs2.next()) {
                bookingNameList.add(rs2.getString("FLIGHT"));
                daylist.add(rs2.getString("DATES"));
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return bookingNameList;
    }

    public static boolean checkbooking(String customer, String day) {
        try {
            Connection connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
            PreparedStatement getname = connection.prepareStatement("FIND");
            getname.setString(1, day);
            ResultSet rs2 = getname.executeQuery();
            bookingNameList.clear();
            while (rs2.next()) {
                bookingNameList.add(rs2.getString("NAME"));

            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        check = true;
        for (int i = 0; i < namelist.size(); i++) {
            if (customer == namelist.get(i)) {
                check = false;

            }
        }
        return check;
    }

}
